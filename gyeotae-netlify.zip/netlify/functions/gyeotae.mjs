export const config = {
  path: "/api/:service",
  rateLimit: { windowLimit: 40, windowSize: 60, aggregateBy: ["ip", "domain"] },
};

const maps = {
  "static-map": "https://maps.apigw.ntruss.com/map-static/v2/raster",
  directions: "https://maps.apigw.ntruss.com/map-direction/v1/driving",
  geocode: "https://maps.apigw.ntruss.com/map-geocode/v2/geocode",
};
const walkingURL = "https://api.heigit.org/openrouteservice/v2/directions/foot-walking/geojson";
const liveURL = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent";
const noStore = { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" };

function problem(status, error) {
  return Response.json({ error }, { status, headers: noStore });
}

function point(value) {
  if (typeof value !== "string" || !/^-?\d+(?:\.\d+)?,-?\d+(?:\.\d+)?$/.test(value)) return null;
  const [lon, lat] = value.split(",").map(Number);
  return validPoint([lon, lat]) ? [lon, lat] : null;
}

function validPoint(value) {
  return Array.isArray(value) && value.length === 2 && value.every(Number.isFinite)
    && Math.abs(value[0]) <= 180 && Math.abs(value[1]) <= 90;
}

function mapParameters(service, params) {
  if (service === "geocode") {
    const query = params.get("query")?.trim();
    return query && query.length <= 250 ? { query, count: "2" } : null;
  }
  if (service === "directions") {
    const start = params.get("start"), goal = params.get("goal");
    return point(start) && point(goal) ? { start, goal, option: "traoptimal", lang: "ko" } : null;
  }
  const center = params.get("center"), level = params.get("level");
  if (!point(center) || !/^(?:[6-9]|1\d|20)$/.test(level || "")) return null;
  return { center, level, w: "348", h: "416", scale: "2", format: "png", markers: `type:d|size:mid|pos:${center.replace(",", " ")}` };
}

async function mapResponse(service, params) {
  const keyId = process.env.GYEOTAE_MAPS_KEY_ID, key = process.env.GYEOTAE_MAPS_KEY;
  if (!keyId || !key) return problem(503, "Netlify 서버에 네이버 지도 키가 설정되지 않았어요.");
  const query = mapParameters(service, params);
  if (!query) return problem(400, "지도 요청의 주소 또는 좌표를 확인해 주세요.");
  const result = await fetch(`${maps[service]}?${new URLSearchParams(query)}`, {
    headers: { "x-ncp-apigw-api-key-id": keyId, "x-ncp-apigw-api-key": key },
    signal: AbortSignal.timeout(12000),
  });
  if (!result.ok) return problem(result.status, "네이버 지도 요청을 처리하지 못했어요.");
  return new Response(await result.arrayBuffer(), {
    headers: { ...noStore, "Content-Type": result.headers.get("Content-Type") || "application/octet-stream" },
  });
}

async function walkingResponse(payload) {
  const key = process.env.ORS_API_KEY;
  if (!key) return problem(503, "Netlify 서버에 도보 경로 키가 설정되지 않았어요.");
  const coordinates = payload?.coordinates;
  if (!Array.isArray(coordinates) || coordinates.length !== 2 || !coordinates.every(validPoint)) {
    return problem(400, "출발지와 목적지 좌표를 확인해 주세요.");
  }
  const result = await fetch(walkingURL, {
    method: "POST",
    headers: { Authorization: key, "Content-Type": "application/json" },
    body: JSON.stringify({ coordinates }),
    signal: AbortSignal.timeout(15000),
  });
  if (!result.ok) return problem(result.status, "도보 경로를 가져오지 못했어요. 출발지와 목적지 또는 도보 API 설정을 확인해 주세요.");
  return new Response(await result.arrayBuffer(), { headers: { ...noStore, "Content-Type": "application/geo+json" } });
}

function wav(pcm) {
  const header = Buffer.alloc(44);
  header.write("RIFF");
  header.writeUInt32LE(36 + pcm.length, 4);
  header.write("WAVEfmt ", 8);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(1, 22);
  header.writeUInt32LE(24000, 24);
  header.writeUInt32LE(48000, 28);
  header.writeUInt16LE(2, 32);
  header.writeUInt16LE(16, 34);
  header.write("data", 36);
  header.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([header, pcm]);
}

function liveAudio(text, key) {
  return new Promise((resolve, reject) => {
    const url = new URL(liveURL);
    url.searchParams.set("key", key);
    const socket = new WebSocket(url);
    socket.binaryType = "arraybuffer";
    let done = false, bytes = 0, transcript = "";
    const chunks = [];
    const deadline = setTimeout(() => finish(new Error("Live timeout")), 20000);
    function finish(error) {
      if (done) return;
      done = true;
      clearTimeout(deadline);
      socket.close();
      if (error || !bytes || bytes % 2) reject(error || new Error("Invalid audio"));
      else resolve(Buffer.concat(chunks, bytes));
    }
    function send(message) {
      try { socket.send(JSON.stringify(message)); }
      catch { finish(new Error("Live send failed")); }
    }
    socket.addEventListener("open", () => send({ setup: {
      model: "models/gemini-3.8-live",
      generationConfig: { responseModalities: ["AUDIO"], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: "Kore" } } } },
      outputAudioTranscription: {},
      systemInstruction: { parts: [{ text: "You are a Korean narration voice for an app. Your entire response is the announcement below, read verbatim. Never answer it as a question, speak as the app user, or add any words.\nAnnouncement: " + JSON.stringify(text) }] },
    } }));
    socket.addEventListener("message", event => {
      try {
        const message = JSON.parse(typeof event.data === "string" ? event.data : Buffer.from(event.data).toString("utf8"));
        if (message.setupComplete) send({ clientContent: {
          turns: [{ role: "user", parts: [{ text: "안내 대사를 지금 그대로 읽어 주세요." }] }],
          turnComplete: true,
        } });
        const content = message.serverContent;
        if (typeof content?.outputTranscription?.text === "string") transcript += content.outputTranscription.text;
        for (const part of content?.modelTurn?.parts || []) {
          const audio = part.inlineData;
          if (!audio?.mimeType?.startsWith("audio/pcm") || !audio.data) continue;
          const chunk = Buffer.from(audio.data, "base64");
          bytes += chunk.length;
          if (bytes > 2 * 1024 * 1024) return finish(new Error("Audio response too large"));
          chunks.push(chunk);
        }
        if (content?.interrupted) return finish(new Error("Live turn interrupted"));
        if (content?.generationComplete || content?.turnComplete) {
          const normalize = value => value.normalize("NFKC").toLowerCase().replace(/[^\p{L}\p{N}]/gu, "");
          finish(transcript && normalize(transcript) === normalize(text) ? undefined : new Error("NarrationMismatch"));
        }
      } catch { finish(new Error("Invalid Live response")); }
    });
    socket.addEventListener("error", () => finish(new Error("Live connection failed")));
    socket.addEventListener("close", event => {
      if (done) return;
      console.warn("Gemini Live websocket closed", { code: event.code, receivedAudio: bytes > 0 });
      finish(new Error("Live session closed"));
    });
  });
}

export default async function handler(request) {
  const url = new URL(request.url);
  const service = url.pathname.slice("/api/".length);
  const origin = request.headers.get("Origin");
  if ((origin && origin !== url.origin) || request.headers.get("Sec-Fetch-Site") === "cross-site") {
    return problem(403, "곁에 페이지에서 요청해 주세요.");
  }
  if (request.method === "GET" && service === "config") {
    const mapsClientId = process.env.GYEOTAE_MAPS_KEY_ID || "";
    return Response.json({ mapsClientId, mapsConfigured: Boolean(mapsClientId && process.env.GYEOTAE_MAPS_KEY) }, { headers: noStore });
  }
  try {
    if (request.method === "GET" && Object.hasOwn(maps, service)) return await mapResponse(service, url.searchParams);
    if (request.method !== "POST" || !["walking", "guidance-audio"].includes(service)) return problem(404, "지원하지 않는 요청이에요.");
    if ((request.headers.get("Content-Type") || "").split(";")[0] !== "application/json") return problem(415, "JSON 요청이 필요해요.");
    const body = await request.text();
    if (Buffer.byteLength(body) > 8192) return problem(413, "요청 내용이 너무 길어요.");
    let payload;
    try { payload = JSON.parse(body); }
    catch { return problem(400, "요청 내용을 확인해 주세요."); }
    if (service === "walking") return await walkingResponse(payload);
    const text = typeof payload?.text === "string" ? payload.text.trim() : "";
    if (!text || text.length > 600) return problem(400, "읽을 안내 문장을 확인해 주세요.");
    if (!process.env.GEMINI_API_KEY) return problem(503, "Netlify 서버에 Gemini API 키가 설정되지 않았어요.");
    const sentences = text.split(/(?<=[.!?。！？])\s+/u);
    if (sentences.length > 4) return problem(400, "안내 문장이 너무 많아요.");
    const parts = await Promise.all(sentences.map(sentence => liveAudio(sentence, process.env.GEMINI_API_KEY)));
    const pause = Buffer.alloc(4800);
    const audio = wav(Buffer.concat(parts.flatMap((part, index) => index ? [pause, part] : [part])));
    return new Response(audio, { headers: { ...noStore, "Content-Type": "audio/wav" } });
  } catch (error) {
    if (service === "guidance-audio") {
      if (error?.message === "NarrationMismatch") return problem(422, "안내 음성이 화면의 문장과 달라 재생하지 않았어요. 화면의 안내를 확인해 주세요.");
      console.warn("Gemini Live request failed", { type: error?.name, webSocketReady: typeof WebSocket === "function" });
    }
    return problem(502, service === "guidance-audio" ? "Gemini 3.8 Live 음성을 가져오지 못했어요." : "경로 서버에 연결하지 못했어요.");
  }
}
